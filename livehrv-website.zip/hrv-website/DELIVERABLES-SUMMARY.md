# HRV Website Deliverables Summary

This folder contains a complete Next.js website you can deploy for livehrv.com.

## Highlights
- Premium black/white minimal design
- Full page set (Home, Product, Science, Protocol, About, FAQ, Contact + Legal)
- Mobile responsive
- SEO: sitemap + robots
- Centralized content: data/content.ts

## Next Steps
- Replace product image placeholders with real photography
- Connect ecommerce (Shopify/Stripe) and email provider (Klaviyo/ConvertKit)
- Update legal pages with counsel-reviewed docs
