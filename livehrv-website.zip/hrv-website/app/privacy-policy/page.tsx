import { Section } from "@/components/Section";

export const metadata = { title: "Privacy Policy" };

export default function PrivacyPolicy() {
  return (
    <div>
      <Section
        eyebrow="LEGAL"
        title="Privacy Policy"
        subtitle="Template only. Replace with counsel-reviewed policy before launch."
      >
        <div className="prose prose-sm max-w-none">
          <p>
            This Privacy Policy describes how HRV collects, uses, and shares information when you visit livehrv.com.
          </p>
          <h3>Information we collect</h3>
          <ul>
            <li>Contact info you submit (like email address)</li>
            <li>Basic analytics (like page views)</li>
            <li>Order details (once ecommerce is connected)</li>
          </ul>
          <h3>How we use information</h3>
          <ul>
            <li>To provide and improve the site</li>
            <li>To communicate with you (if you opt in)</li>
            <li>To process orders (once enabled)</li>
          </ul>
          <h3>Contact</h3>
          <p>support@livehrv.com</p>
        </div>
      </Section>
    </div>
  );
}
