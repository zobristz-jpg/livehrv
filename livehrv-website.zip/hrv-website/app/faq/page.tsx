"use client";

import { useState } from "react";
import { Section } from "@/components/Section";
import { faq } from "@/data/content";

function QA({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="rounded-2xl border border-black/10 bg-white p-6 shadow-soft">
      <button className="flex w-full items-start justify-between gap-6 text-left" onClick={() => setOpen(!open)}>
        <p className="text-sm font-medium">{q}</p>
        <span className="text-sm text-black/50">{open ? "−" : "+"}</span>
      </button>
      {open ? <p className="mt-3 text-sm text-black/70">{a}</p> : null}
    </div>
  );
}

export const metadata = {
  title: "FAQ"
};

export default function FAQPage() {
  return (
    <div>
      <Section
        eyebrow="FAQ"
        title="Answers without hype."
        subtitle="If you still have questions, contact support@livehrv.com."
      >
        <div className="grid gap-10">
          <div>
            <p className="text-xs font-medium tracking-wide text-black/60">PRODUCT</p>
            <div className="mt-4 grid gap-4 md:grid-cols-2">
              {faq.product.map((x) => (
                <QA key={x.q} q={x.q} a={x.a} />
              ))}
            </div>
          </div>

          <div>
            <p className="text-xs font-medium tracking-wide text-black/60">SCIENCE & INGREDIENTS</p>
            <div className="mt-4 grid gap-4 md:grid-cols-2">
              {faq.science.map((x) => (
                <QA key={x.q} q={x.q} a={x.a} />
              ))}
            </div>
          </div>

          <div>
            <p className="text-xs font-medium tracking-wide text-black/60">SUBSCRIPTION & ORDERING</p>
            <div className="mt-4 grid gap-4 md:grid-cols-2">
              {faq.ordering.map((x) => (
                <QA key={x.q} q={x.q} a={x.a} />
              ))}
            </div>
          </div>
        </div>
      </Section>
    </div>
  );
}
