import { Section } from "@/components/Section";
import { Button } from "@/components/Button";
import { product } from "@/data/content";

export const metadata = {
  title: "Science"
};

export default function SciencePage() {
  return (
    <div>
      <Section
        eyebrow="THE SCIENCE"
        title="Recovery you can explain."
        subtitle="Educational content only. No hype. Supportive language. Consult a qualified healthcare professional for personalized guidance."
      >
        <div className="grid gap-4 md:grid-cols-2">
          <div className="rounded-2xl border border-black/10 bg-white p-6 shadow-soft">
            <p className="text-sm font-medium">What is HRV?</p>
            <p className="mt-2 text-sm text-black/70">
              HRV (heart rate variability) is one signal your body uses to reflect recovery and readiness.
              Many athletes track HRV trends to understand how training, stress, and sleep may be influencing resilience.
            </p>
          </div>
          <div className="rounded-2xl border border-black/10 bg-white p-6 shadow-soft">
            <p className="text-sm font-medium">Why sleep matters</p>
            <p className="mt-2 text-sm text-black/70">
              Sleep is where the body does critical recovery work. A consistent wind-down routine can support calmer evenings,
              deeper rest, and better next-day readiness.
            </p>
          </div>
        </div>
      </Section>

      <Section
        eyebrow="INGREDIENTS"
        title="Six ingredients, each with a role."
        subtitle="Transparent doses. No proprietary blends."
      >
        <div className="grid gap-4 md:grid-cols-2">
          {product.formula.map((ing) => (
            <div key={ing.ingredient} className="rounded-2xl border border-black/10 bg-white p-6">
              <p className="text-sm font-medium">{ing.ingredient}</p>
              <p className="mt-1 text-sm text-black/60">{ing.dose}</p>
              <p className="mt-3 text-sm text-black/70">{ing.purpose}</p>
              <p className="mt-3 text-xs text-black/50">
                Note: Add your supporting citations/claims substantiation and COAs before launch.
              </p>
            </div>
          ))}
        </div>
      </Section>

      <Section
        eyebrow="QUALITY"
        title="Standards you can publish."
        subtitle="These are placeholders—replace with your exact manufacturing and testing details."
      >
        <div className="grid gap-4 md:grid-cols-4">
          {[
            ["GMP manufacturing", "Manufactured in a GMP-compliant facility."],
            ["Third-party testing", "Independent testing for key quality markers."],
            ["No proprietary blends", "Every dose is visible on the label."],
            ["Transparent sourcing", "Publish what you can prove."]
          ].map(([t, d]) => (
            <div key={t} className="rounded-2xl border border-black/10 bg-white p-6 shadow-soft">
              <p className="text-sm font-medium">{t}</p>
              <p className="mt-2 text-sm text-black/70">{d}</p>
            </div>
          ))}
        </div>

        <div className="mt-8 rounded-2xl bg-hrv-black p-7 text-white">
          <p className="text-xs font-medium tracking-wide text-white/70">IMPORTANT</p>
          <p className="mt-3 text-sm text-white/80">
            This site is for educational purposes only and does not provide medical advice.
            Supplements may interact with medications or conditions. Consult a qualified professional.
          </p>
        </div>

        <div className="mt-8">
          <Button href="/products/dusk">Shop HRV Dusk</Button>
        </div>
      </Section>
    </div>
  );
}
