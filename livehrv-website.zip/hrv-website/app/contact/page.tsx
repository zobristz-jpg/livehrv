"use client";

import { useState } from "react";
import { Section } from "@/components/Section";
import { Button } from "@/components/Button";

export const metadata = {
  title: "Contact"
};

export default function ContactPage() {
  const [sent, setSent] = useState(false);

  function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSent(true);
  }

  return (
    <div>
      <Section
        eyebrow="SUPPORT"
        title="Contact"
        subtitle="We’ll respond as soon as possible. Replace this form handler with your email provider or helpdesk."
      >
        <div className="grid gap-6 md:grid-cols-[2fr_1fr]">
          <div className="rounded-2xl border border-black/10 bg-white p-6 shadow-soft">
            {sent ? (
              <div className="rounded-xl bg-black/[0.04] p-4 text-sm text-black/75">
                Message sent (placeholder). Replace with real form handling.
              </div>
            ) : (
              <form onSubmit={onSubmit} className="grid gap-4">
                <div className="grid gap-2">
                  <label className="text-xs font-medium text-black/60">Name</label>
                  <input className="rounded-xl border border-black/15 px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-black/15" required />
                </div>
                <div className="grid gap-2">
                  <label className="text-xs font-medium text-black/60">Email</label>
                  <input type="email" className="rounded-xl border border-black/15 px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-black/15" required />
                </div>
                <div className="grid gap-2">
                  <label className="text-xs font-medium text-black/60">Subject</label>
                  <select className="rounded-xl border border-black/15 px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-black/15">
                    <option>Product</option>
                    <option>Order</option>
                    <option>Subscription</option>
                    <option>Ingredients</option>
                    <option>Wholesale</option>
                    <option>Other</option>
                  </select>
                </div>
                <div className="grid gap-2">
                  <label className="text-xs font-medium text-black/60">Message</label>
                  <textarea className="min-h-[130px] rounded-xl border border-black/15 px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-black/15" required />
                </div>
                <Button type="submit">Send</Button>
              </form>
            )}
          </div>

          <div className="rounded-2xl border border-black/10 bg-white p-6 shadow-soft">
            <p className="text-sm font-medium">Support</p>
            <p className="mt-2 text-sm text-black/70">support@livehrv.com</p>
            <p className="mt-4 text-xs text-black/55">Hours: Mon–Fri, 9am–6pm</p>
            <div className="mt-6 rounded-xl bg-black/[0.04] p-4 text-xs text-black/65">
              For fast answers, check the FAQ.
            </div>
          </div>
        </div>
      </Section>
    </div>
  );
}
