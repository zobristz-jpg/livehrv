import { Section } from "@/components/Section";
import { Button } from "@/components/Button";

export const metadata = {
  title: "Protocol"
};

export default function ProtocolPage() {
  return (
    <div>
      <Section
        eyebrow="NIGHT RECOVERY PROTOCOL"
        title="Consistency over perfection."
        subtitle="A simple, disciplined routine for athletes and leaders. Build a night that supports recovery and next-day readiness."
      >
        <div className="grid gap-4 md:grid-cols-2">
          {[
            [
              "6–8 hours before bed",
              "Cut caffeine. Plan dinner. Train smart. Recovery starts long before your head hits the pillow."
            ],
            [
              "2–3 hours before bed",
              "Dim lights. Cool the room. Reduce stimulation. Quiet inputs to quiet outputs."
            ],
            [
              "30–60 minutes before bed",
              "Take HRV Dusk. Prep tomorrow. Breathwork or prayer. Protect the threshold into sleep."
            ],
            [
              "Sleep environment",
              "Dark, cool, quiet. Devices out. Your room is a recovery chamber."
            ]
          ].map(([t, d]) => (
            <div key={t} className="rounded-2xl border border-black/10 bg-white p-6 shadow-soft">
              <p className="text-sm font-medium">{t}</p>
              <p className="mt-2 text-sm text-black/70">{d}</p>
            </div>
          ))}
        </div>
      </Section>

      <Section
        eyebrow="PRINCIPLES"
        title="Build the ritual that builds you."
        subtitle="Keep it simple. Make it repeatable."
      >
        <div className="grid gap-4 md:grid-cols-4">
          {[
            ["Consistency", "Small disciplines, repeated nightly."],
            ["Individualize", "Adjust timing, dose, and routine to your reality."],
            ["Respect", "Protect sleep like training—schedule it, defend it."],
            ["Measure", "Track how you feel. Use HRV trends as one signal—not a god."]
          ].map(([t, d]) => (
            <div key={t} className="rounded-2xl border border-black/10 bg-white p-6 shadow-soft">
              <p className="text-sm font-medium">{t}</p>
              <p className="mt-2 text-sm text-black/70">{d}</p>
            </div>
          ))}
        </div>

        <div className="mt-10 rounded-3xl bg-hrv-black p-10 text-white">
          <p className="text-xs font-medium tracking-wide text-white/70">READY TO BUILD YOUR RITUAL?</p>
          <h3 className="mt-3 font-display text-3xl">HRV Dusk fits here.</h3>
          <p className="mt-3 max-w-2xl text-sm text-white/70">
            Take it 30–60 minutes before bed as your anchor habit—hot or cold, water or milk.
          </p>
          <div className="mt-7">
            <Button href="/products/dusk" className="bg-white text-black hover:bg-white/90">
              Shop HRV Dusk
            </Button>
          </div>
        </div>
      </Section>
    </div>
  );
}
