import { Section } from "@/components/Section";

export const metadata = { title: "Terms" };

export default function Terms() {
  return (
    <div>
      <Section
        eyebrow="LEGAL"
        title="Terms of Service"
        subtitle="Template only. Replace with counsel-reviewed terms before launch."
      >
        <div className="prose prose-sm max-w-none">
          <p>
            By accessing this site, you agree to these Terms. If you do not agree, do not use the site.
          </p>
          <h3>Products and orders</h3>
          <p>
            Product descriptions and pricing are subject to change. Checkout features are placeholders until ecommerce is enabled.
          </p>
          <h3>Subscriptions</h3>
          <p>
            Subscription features are placeholders. When enabled, you will be able to manage, pause, or cancel as described.
          </p>
          <h3>Limitation of liability</h3>
          <p>
            To the maximum extent permitted by law, HRV is not liable for indirect or consequential damages.
          </p>
          <h3>Contact</h3>
          <p>support@livehrv.com</p>
        </div>
      </Section>
    </div>
  );
}
