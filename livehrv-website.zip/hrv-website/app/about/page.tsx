import { Section } from "@/components/Section";
import { brand } from "@/data/content";
import { Button } from "@/components/Button";

export const metadata = {
  title: "About"
};

export default function AboutPage() {
  return (
    <div>
      <Section
        eyebrow="ABOUT HRV"
        title="Built for service."
        subtitle="HRV exists for disciplined people who want to train hard, recover well, and stay ready to carry more."
      >
        <div className="grid gap-4 md:grid-cols-2">
          <div className="rounded-2xl border border-black/10 bg-white p-6 shadow-soft">
            <p className="text-sm font-medium">Why HRV exists</p>
            <p className="mt-2 text-sm text-black/70">
              Most performance culture talks about output. HRV is about readiness. We built HRV for the person who
              doesn’t just want to perform—but wants to endure.
            </p>
            <p className="mt-3 text-sm text-black/70">
              Sleep is protected. Recovery is intentional. Strength is aimed at service.
            </p>
          </div>
          <div className="rounded-2xl border border-black/10 bg-white p-6 shadow-soft">
            <p className="text-sm font-medium">Tone and conviction</p>
            <p className="mt-2 text-sm text-black/70">
              No cringe. No hype. Quiet conviction. Premium restraint. A ritual, not a trend.
            </p>
            <p className="mt-3 text-sm text-black/70">
              We speak in supportive language and publish what we can prove.
            </p>
          </div>
        </div>
      </Section>

      <Section
        eyebrow="PILLARS"
        title="Three lines that hold the brand."
        subtitle="Short enough to remember. Deep enough to live."
      >
        <div className="grid gap-4 md:grid-cols-3">
          {brand.pillars.map((p) => (
            <div key={p.title} className="rounded-2xl border border-black/10 bg-white p-6 shadow-soft">
              <p className="text-sm font-medium">{p.title}</p>
              <p className="mt-2 text-sm text-black/70">{p.description}</p>
            </div>
          ))}
        </div>

        <div className="mt-10 rounded-3xl bg-hrv-black p-10 text-white">
          <p className="text-xs font-medium tracking-wide text-white/70">WHO WE’RE FOR</p>
          <div className="mt-6 grid gap-4 md:grid-cols-2">
            {[
              ["Disciplined athletes", "CrossFit and HYROX athletes who care about readiness."],
              ["Purpose-driven leaders", "People who carry responsibility and need endurance."],
              ["Quality-minded buyers", "Premium minimalism, transparent labels, real doses."],
              ["Ritual builders", "Those who prefer repeatable habits over hacks."]
            ].map(([t, d]) => (
              <div key={t} className="rounded-2xl border border-white/15 bg-white/5 p-6">
                <p className="text-sm font-medium">{t}</p>
                <p className="mt-2 text-sm text-white/70">{d}</p>
              </div>
            ))}
          </div>
          <div className="mt-7">
            <Button href="/products/dusk" className="bg-white text-black hover:bg-white/90">
              Shop HRV Dusk
            </Button>
          </div>
        </div>
      </Section>
    </div>
  );
}
