import { Section } from "@/components/Section";

export const metadata = { title: "Disclaimer" };

export default function Disclaimer() {
  return (
    <div>
      <Section
        eyebrow="LEGAL"
        title="Medical Disclaimer"
        subtitle="Template only. Replace with counsel-reviewed disclaimer before launch."
      >
        <div className="prose prose-sm max-w-none">
          <p><strong>Important:</strong> This site does not provide medical advice.</p>
          <p>
            The information provided is for general educational purposes only and is not intended as medical advice.
            Always consult a qualified healthcare professional regarding supplements, medications, or conditions.
          </p>
          <p>
            <strong>FDA statement:</strong> These statements have not been evaluated by the Food and Drug Administration.
            This product is not intended to diagnose, treat, cure, or prevent any disease.
          </p>
        </div>
      </Section>
    </div>
  );
}
