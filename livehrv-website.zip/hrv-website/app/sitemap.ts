import type { MetadataRoute } from "next";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = "https://livehrv.com";
  const routes = [
    "",
    "/products/dusk",
    "/science",
    "/protocol",
    "/about",
    "/faq",
    "/contact",
    "/privacy-policy",
    "/terms",
    "/disclaimer"
  ];

  return routes.map((path) => ({
    url: `${base}${path}`,
    lastModified: new Date()
  }));
}
