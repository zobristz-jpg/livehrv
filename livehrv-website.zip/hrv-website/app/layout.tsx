import "./globals.css";
import type { Metadata } from "next";
import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";

export const metadata: Metadata = {
  metadataBase: new URL("https://livehrv.com"),
  title: {
    default: "HRV | Night Recovery Ritual",
    template: "%s | HRV"
  },
  description:
    "Premium nighttime recovery supplements for disciplined athletes and purpose-driven leaders. Sleep is worship. Recovery is stewardship. Strength is service.",
  openGraph: {
    title: "HRV | Night Recovery Ritual",
    description:
      "Premium nighttime recovery supplements for disciplined athletes and purpose-driven leaders.",
    url: "https://livehrv.com",
    siteName: "HRV",
    type: "website"
  },
  robots: {
    index: true,
    follow: true
  }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Navigation />
        <main className="min-h-[70vh]">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
