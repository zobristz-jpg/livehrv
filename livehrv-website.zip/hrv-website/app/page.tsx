import Link from "next/link";
import { Button } from "@/components/Button";
import { EmailCapture } from "@/components/EmailCapture";
import { Section } from "@/components/Section";
import { brand, product, testimonials } from "@/data/content";

function JarPlaceholder() {
  return (
    <div className="relative mx-auto aspect-square w-full max-w-[520px] rounded-3xl bg-gradient-to-b from-black/[0.06] to-black/[0.02] p-8 shadow-soft">
      <div className="absolute inset-0 rounded-3xl ring-1 ring-black/10" />
      <div className="flex h-full flex-col items-center justify-center gap-4">
        <div className="h-16 w-16 rounded-2xl bg-black text-white flex items-center justify-center font-semibold">
          HRV
        </div>
        <div className="text-center">
          <p className="text-xs tracking-wide text-black/50">PRODUCT IMAGE PLACEHOLDER</p>
          <p className="mt-1 text-sm font-medium">{product.name}</p>
          <p className="text-xs text-black/60">{product.subtitle}</p>
        </div>
      </div>
    </div>
  );
}

export default function HomePage() {
  return (
    <div>
      {/* Hero */}
      <section className="py-16 md:py-24">
        <div className="mx-auto max-w-[1400px] px-6">
          <div className="grid items-center gap-12 md:grid-cols-2">
            <div>
              <p className="text-xs font-medium tracking-wide text-black/60">LIVEHRV.COM</p>
              <h1 className="mt-3 font-display text-5xl leading-[1.05] md:text-6xl">
                Sleep is worship.
              </h1>
              <p className="mt-5 max-w-xl text-base text-black/70">
                Premium nighttime recovery for disciplined athletes and purpose-driven leaders.
                Build a ritual that supports calm, deeper rest, and next-day readiness.
              </p>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <Button href="/products/dusk">Shop HRV Dusk</Button>
                <Button href="/protocol" variant="secondary">
                  View Protocol
                </Button>
              </div>
              <div className="mt-8 grid gap-3 text-sm text-black/70 sm:grid-cols-2">
                <div className="rounded-2xl border border-black/10 bg-white p-4">
                  <p className="text-xs font-medium text-black/60">TRANSPARENT DOSES</p>
                  <p className="mt-1">No proprietary blends. Built to be understood.</p>
                </div>
                <div className="rounded-2xl border border-black/10 bg-white p-4">
                  <p className="text-xs font-medium text-black/60">RITUAL FRIENDLY</p>
                  <p className="mt-1">Hot or cold. Water or milk. Nightly consistency.</p>
                </div>
              </div>
            </div>
            <JarPlaceholder />
          </div>
        </div>
      </section>

      {/* Pillars */}
      <section className="border-y border-black/10 bg-hrv-black py-12">
        <div className="mx-auto max-w-[1400px] px-6">
          <div className="grid gap-8 md:grid-cols-3">
            {brand.pillars.map((p) => (
              <div key={p.title}>
                <p className="text-sm font-medium text-white">{p.title}</p>
                <p className="mt-2 text-sm text-white/70">{p.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits */}
      <Section
        eyebrow="DESIGNED FOR PERFORMANCE"
        title="Calm your night. Protect your recovery."
        subtitle="HRV Dusk supports a disciplined wind-down so you can wake ready to train, lead, and serve."
      >
        <div className="grid gap-4 md:grid-cols-3">
          {[
            ["Calm", "Supports a quieter nervous system at night."],
            ["Sleep quality", "Helps promote deeper, more restorative rest."],
            ["Next-day readiness", "Built to support morning clarity—no hype."],
            ["Recovery", "Supports the foundation your training depends on."],
            ["Consistency", "A simple ritual you can repeat nightly."],
            ["Transparency", "Label-forward doses you can trust."]
          ].map(([t, d]) => (
            <div key={t} className="rounded-2xl border border-black/10 bg-white p-6 shadow-soft">
              <p className="text-sm font-medium">{t}</p>
              <p className="mt-2 text-sm text-black/70">{d}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* How it works */}
      <Section
        eyebrow="HOW IT WORKS"
        title="A simple sequence that compounds"
        subtitle="You don’t need more hacks. You need a ritual that supports recovery night after night."
      >
        <div className="grid gap-4 md:grid-cols-4">
          {[
            ["Signal wind-down", "Support calm and sleep onset."],
            ["Support depth", "Promote more restorative rest."],
            ["Protect recovery", "Support the work your body does overnight."],
            ["Wake ready", "Support next-day readiness and clarity."]
          ].map(([t, d], i) => (
            <div key={t} className="rounded-2xl border border-black/10 bg-white p-6">
              <p className="text-xs font-medium text-black/60">STEP {i + 1}</p>
              <p className="mt-2 text-sm font-medium">{t}</p>
              <p className="mt-2 text-sm text-black/70">{d}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* Ingredients */}
      <Section
        eyebrow="RESEARCH-BACKED FORMULA"
        title="Six ingredients. Transparent doses."
        subtitle="Built for calm, sleep quality, and recovery—without proprietary blends."
      >
        <div className="grid gap-4 md:grid-cols-2">
          {product.formula.map((ing) => (
            <div key={ing.ingredient} className="rounded-2xl border border-black/10 bg-white p-6">
              <div className="flex items-baseline justify-between gap-4">
                <p className="text-sm font-medium">{ing.ingredient}</p>
                <p className="text-sm text-black/60">{ing.dose}</p>
              </div>
              <p className="mt-2 text-sm text-black/70">{ing.purpose}</p>
            </div>
          ))}
        </div>
        <div className="mt-6">
          <Button href="/science" variant="secondary">
            Learn the science
          </Button>
        </div>
      </Section>

      {/* Testimonials */}
      <Section
        eyebrow="ATHLETE PROOF"
        title="Quiet confidence from real routines"
        subtitle="Placeholders you can replace with real customer reviews at launch."
      >
        <div className="grid gap-4 md:grid-cols-3">
          {testimonials.map((t) => (
            <div key={t.name} className="rounded-2xl border border-black/10 bg-white p-6 shadow-soft">
              <p className="text-sm text-black/80">“{t.quote}”</p>
              <div className="mt-4">
                <p className="text-sm font-medium">{t.name}</p>
                <p className="text-xs text-black/60">{t.role}</p>
              </div>
            </div>
          ))}
        </div>
      </Section>

      {/* Ritual */}
      <Section
        eyebrow="THE RITUAL"
        title="Make it nightly. Make it simple."
        subtitle="Hot or cold. Water or milk. 30–60 minutes before bed."
      >
        <div className="grid gap-4 md:grid-cols-3">
          {[
            ["Timing", product.howToUse.timing],
            ["Mix", product.howToUse.mix],
            ["Hot or cold", product.howToUse.hotOrCold]
          ].map(([t, d]) => (
            <div key={t} className="rounded-2xl border border-black/10 bg-white p-6">
              <p className="text-sm font-medium">{t}</p>
              <p className="mt-2 text-sm text-black/70">{d}</p>
            </div>
          ))}
        </div>
        <div className="mt-8 rounded-2xl border border-black/10 bg-white p-6">
          <p className="text-sm font-medium">Taste profile</p>
          <p className="mt-2 text-sm text-black/70">{product.taste}</p>
        </div>
      </Section>

      {/* Email capture */}
      <section className="py-16 md:py-20">
        <div className="mx-auto max-w-[1400px] px-6">
          <EmailCapture />
        </div>
      </section>

      {/* CTA */}
      <section className="border-t border-black/10 py-14">
        <div className="mx-auto max-w-[1400px] px-6">
          <div className="rounded-3xl bg-hrv-black p-10 text-white md:p-12">
            <p className="text-xs font-medium tracking-wide text-white/70">HRV DUSK</p>
            <h3 className="mt-3 font-display text-3xl md:text-4xl">Build your night recovery ritual.</h3>
            <p className="mt-3 max-w-2xl text-sm text-white/70">
              Calm power. Reverent stillness. Recovery that supports service.
            </p>
            <div className="mt-7 flex flex-col gap-3 sm:flex-row">
              <Link
                href="/products/dusk"
                className="inline-flex items-center justify-center rounded-xl bg-white px-5 py-3 text-sm font-medium text-black hover:bg-white/90"
              >
                Shop HRV Dusk
              </Link>
              <Link
                href="/protocol"
                className="inline-flex items-center justify-center rounded-xl border border-white/20 px-5 py-3 text-sm font-medium text-white hover:bg-white/10"
              >
                View Protocol
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
