"use client";

import { useMemo, useState } from "react";
import { Button } from "@/components/Button";
import { product } from "@/data/content";

function JarHero() {
  return (
    <div className="sticky top-24 rounded-3xl border border-black/10 bg-gradient-to-b from-black/[0.06] to-black/[0.02] p-8 shadow-soft">
      <div className="aspect-square w-full rounded-2xl bg-white ring-1 ring-black/10 flex items-center justify-center">
        <div className="text-center">
          <div className="mx-auto h-16 w-16 rounded-2xl bg-black text-white flex items-center justify-center font-semibold">
            HRV
          </div>
          <p className="mt-3 text-xs tracking-wide text-black/50">PRODUCT IMAGE PLACEHOLDER</p>
          <p className="mt-1 text-sm font-medium">{product.name}</p>
          <p className="text-xs text-black/60">{product.subtitle}</p>
        </div>
      </div>
      <div className="mt-6 grid gap-2 text-xs text-black/60">
        <div className="flex items-center justify-between">
          <span>GMP</span><span>•</span><span>Third-party tested</span><span>•</span><span>Made in USA</span>
        </div>
      </div>
    </div>
  );
}

export default function ProductDuskPage() {
  const [flavor, setFlavor] = useState(product.flavorOptions[0]);
  const [plan, setPlan] = useState<"oneTime" | "subscribe">("subscribe");
  const [qty, setQty] = useState(1);

  const price = useMemo(() => {
    const base = product.price * qty;
    if (plan === "subscribe") return Math.round(base * (1 - product.subscribeDiscountPercent / 100));
    return base;
  }, [plan, qty]);

  return (
    <div className="py-14 md:py-18">
      <div className="mx-auto max-w-[1400px] px-6">
        <div className="grid gap-10 md:grid-cols-[1.05fr_0.95fr]">
          <div className="hidden md:block">
            <JarHero />
          </div>

          <div>
            <p className="text-xs font-medium tracking-wide text-black/60">PRODUCT</p>
            <h1 className="mt-2 font-display text-4xl md:text-5xl">{product.name}</h1>
            <p className="mt-3 text-sm text-black/70">
              Calm power for the disciplined. A nightly ritual that supports sleep quality, recovery, and next-day readiness.
            </p>

            <div className="mt-8 rounded-2xl border border-black/10 bg-white p-6 shadow-soft">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium">Price</p>
                <p className="text-sm text-black/70">
                  ${price} <span className="text-xs text-black/50">USD</span>
                </p>
              </div>

              <div className="mt-5">
                <p className="text-xs font-medium tracking-wide text-black/60">FLAVOR</p>
                <div className="mt-2 grid grid-cols-2 gap-2">
                  {product.flavorOptions.map((f) => (
                    <button
                      key={f}
                      onClick={() => setFlavor(f)}
                      className={
                        "rounded-xl border px-4 py-3 text-sm transition " +
                        (flavor === f
                          ? "border-black bg-black text-white"
                          : "border-black/15 bg-white hover:bg-black/[0.03]")
                      }
                    >
                      {f}
                    </button>
                  ))}
                </div>
              </div>

              <div className="mt-5">
                <p className="text-xs font-medium tracking-wide text-black/60">PURCHASE</p>
                <div className="mt-2 grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setPlan("oneTime")}
                    className={
                      "rounded-xl border px-4 py-3 text-sm transition " +
                      (plan === "oneTime"
                        ? "border-black bg-black text-white"
                        : "border-black/15 bg-white hover:bg-black/[0.03]")
                    }
                  >
                    One-time
                  </button>
                  <button
                    onClick={() => setPlan("subscribe")}
                    className={
                      "rounded-xl border px-4 py-3 text-sm transition " +
                      (plan === "subscribe"
                        ? "border-black bg-black text-white"
                        : "border-black/15 bg-white hover:bg-black/[0.03]")
                    }
                  >
                    Subscribe & Save {product.subscribeDiscountPercent}%
                  </button>
                </div>
                <p className="mt-2 text-xs text-black/55">
                  Subscription and checkout are placeholders—wire to Shopify/Stripe later.
                </p>
              </div>

              <div className="mt-5 flex items-center justify-between gap-4">
                <div>
                  <p className="text-xs font-medium tracking-wide text-black/60">QUANTITY</p>
                  <div className="mt-2 inline-flex items-center rounded-xl border border-black/15">
                    <button
                      className="px-3 py-2 text-sm hover:bg-black/[0.03] rounded-l-xl"
                      onClick={() => setQty((q) => Math.max(1, q - 1))}
                      aria-label="Decrease quantity"
                    >
                      −
                    </button>
                    <div className="px-4 py-2 text-sm">{qty}</div>
                    <button
                      className="px-3 py-2 text-sm hover:bg-black/[0.03] rounded-r-xl"
                      onClick={() => setQty((q) => q + 1)}
                      aria-label="Increase quantity"
                    >
                      +
                    </button>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xs text-black/55">{product.guarantee}</p>
                  <p className="text-xs text-black/55">{product.shippingNote}</p>
                </div>
              </div>

              <div className="mt-6">
                <Button fullWidth> Add to cart (placeholder)</Button>
              </div>

              <div className="mt-5 grid gap-2 text-xs text-black/60">
                {product.highlights.map((h) => (
                  <div key={h} className="flex gap-2">
                    <span>•</span>
                    <span>{h}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Mobile jar */}
            <div className="mt-8 md:hidden">
              <JarHero />
            </div>

            {/* What you'll feel */}
            <div className="mt-12">
              <p className="text-xs font-medium tracking-wide text-black/60">WHAT YOU’LL FEEL</p>
              <h2 className="mt-2 font-display text-3xl">Time-based clarity</h2>
              <p className="mt-3 text-sm text-black/70">
                Supportive language only. Individual response varies. Consistency matters.
              </p>

              <div className="mt-6 grid gap-4 md:grid-cols-2">
                {[
                  ["Within 30 minutes", "A calmer evening—less noise, more stillness."],
                  ["During sleep", "Support for deeper, more restorative rest."],
                  ["Morning after", "Wake with clarity—ready to train and serve."],
                  ["Over time", "A ritual that compounds when repeated nightly."]
                ].map(([t, d]) => (
                  <div key={t} className="rounded-2xl border border-black/10 bg-white p-6 shadow-soft">
                    <p className="text-sm font-medium">{t}</p>
                    <p className="mt-2 text-sm text-black/70">{d}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Formula */}
            <div className="mt-12">
              <p className="text-xs font-medium tracking-wide text-black/60">FORMULA</p>
              <h2 className="mt-2 font-display text-3xl">Transparent, research-backed doses</h2>
              <p className="mt-3 text-sm text-black/70">
                Serving size {product.servingSizeG}g • {product.servings} servings per container
              </p>

              <div className="mt-6 grid gap-4 md:grid-cols-2">
                {product.formula.map((ing) => (
                  <div key={ing.ingredient} className="rounded-2xl border border-black/10 bg-white p-6">
                    <div className="flex items-baseline justify-between gap-4">
                      <p className="text-sm font-medium">{ing.ingredient}</p>
                      <p className="text-sm text-black/60">{ing.dose}</p>
                    </div>
                    <p className="mt-2 text-sm text-black/70">{ing.purpose}</p>
                  </div>
                ))}
              </div>

              <div className="mt-6 rounded-2xl bg-hrv-black p-7 text-white">
                <p className="text-xs font-medium tracking-wide text-white/70">WHY THIS FORMULA</p>
                <p className="mt-3 text-sm text-white/80">
                  Built to support calm, sleep quality, and recovery with label-forward doses—so you can trust the ritual and repeat it.
                </p>
              </div>
            </div>

            {/* Usage */}
            <div className="mt-12">
              <p className="text-xs font-medium tracking-wide text-black/60">HOW TO USE</p>
              <h2 className="mt-2 font-display text-3xl">Make it nightly</h2>
              <div className="mt-6 grid gap-4 md:grid-cols-3">
                {[
                  ["Timing", product.howToUse.timing],
                  ["Preparation", product.howToUse.mix],
                  ["Consistency", product.howToUse.consistency]
                ].map(([t, d]) => (
                  <div key={t} className="rounded-2xl border border-black/10 bg-white p-6 shadow-soft">
                    <p className="text-sm font-medium">{t}</p>
                    <p className="mt-2 text-sm text-black/70">{d}</p>
                  </div>
                ))}
              </div>

              <div className="mt-6 rounded-2xl border border-black/10 bg-white p-6">
                <p className="text-sm font-medium">Taste</p>
                <p className="mt-2 text-sm text-black/70">{product.taste}</p>
              </div>
            </div>

            {/* Disclaimer */}
            <div className="mt-12 rounded-2xl border border-black/10 bg-white p-6 text-xs text-black/60">
              *These statements have not been evaluated by the Food and Drug Administration. This product is not intended to diagnose, treat, cure, or prevent any disease.
            </div>
          </div>
        </div>
      </div>

      {/* Sticky mobile CTA */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 border-t border-black/10 bg-hrv-white/95 backdrop-blur">
        <div className="mx-auto max-w-[1400px] px-6 py-3 flex items-center justify-between gap-3">
          <div>
            <p className="text-xs text-black/60">HRV Dusk</p>
            <p className="text-sm font-medium">${price}</p>
          </div>
          <Button className="w-[180px]">Add to cart</Button>
        </div>
      </div>
    </div>
  );
}
