import Link from "next/link";
import { cn } from "@/components/cn";

type Variant = "primary" | "secondary" | "ghost";

export function Button({
  children,
  href,
  onClick,
  type = "button",
  variant = "primary",
  className = "",
  fullWidth = false
}: {
  children: React.ReactNode;
  href?: string;
  onClick?: () => void;
  type?: "button" | "submit";
  variant?: Variant;
  className?: string;
  fullWidth?: boolean;
}) {
  const base =
    "inline-flex items-center justify-center rounded-xl px-5 py-3 text-sm font-medium transition focus:outline-none focus:ring-2 focus:ring-black/20";
  const variants: Record<Variant, string> = {
    primary: "bg-hrv-black text-white hover:bg-black/90",
    secondary: "border border-black/15 bg-white text-hrv-black hover:bg-black/[0.03]",
    ghost: "text-hrv-black hover:bg-black/[0.04]"
  };

  const cls = cn(base, variants[variant], fullWidth ? "w-full" : "", className);

  if (href) {
    return (
      <Link className={cls} href={href}>
        {children}
      </Link>
    );
  }

  return (
    <button className={cls} type={type} onClick={onClick}>
      {children}
    </button>
  );
}
