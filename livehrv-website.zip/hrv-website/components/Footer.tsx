import Link from "next/link";

export function Footer() {
  return (
    <footer className="border-t border-black/10 bg-hrv-white">
      <div className="mx-auto max-w-[1400px] px-6 py-12">
        <div className="grid gap-10 md:grid-cols-4">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <span className="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-black text-white text-sm font-semibold">
                H
              </span>
              <span className="text-sm font-semibold tracking-wide">HRV</span>
            </div>
            <p className="text-sm text-black/70">
              Premium recovery for disciplined athletes and purpose-driven leaders.
            </p>
            <p className="text-xs text-black/50">support@livehrv.com</p>
          </div>

          <div className="space-y-2 text-sm">
            <p className="font-medium">Shop</p>
            <Link className="block text-black/70 hover:text-black" href="/products/dusk">
              HRV Dusk
            </Link>
          </div>

          <div className="space-y-2 text-sm">
            <p className="font-medium">Learn</p>
            <Link className="block text-black/70 hover:text-black" href="/science">
              Science
            </Link>
            <Link className="block text-black/70 hover:text-black" href="/protocol">
              Protocol
            </Link>
            <Link className="block text-black/70 hover:text-black" href="/about">
              About
            </Link>
            <Link className="block text-black/70 hover:text-black" href="/faq">
              FAQ
            </Link>
          </div>

          <div className="space-y-2 text-sm">
            <p className="font-medium">Legal</p>
            <Link className="block text-black/70 hover:text-black" href="/privacy-policy">
              Privacy Policy
            </Link>
            <Link className="block text-black/70 hover:text-black" href="/terms">
              Terms
            </Link>
            <Link className="block text-black/70 hover:text-black" href="/disclaimer">
              Disclaimer
            </Link>
          </div>
        </div>

        <div className="mt-10 flex flex-col gap-2 border-t border-black/10 pt-6 text-xs text-black/55 md:flex-row md:items-center md:justify-between">
          <span>© {new Date().getFullYear()} HRV. All rights reserved.</span>
          <span>Sleep is worship. Recovery is stewardship. Strength is service.</span>
        </div>
      </div>
    </footer>
  );
}
