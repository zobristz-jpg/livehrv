"use client";

import Link from "next/link";
import { useState } from "react";
import { Button } from "@/components/Button";

const links = [
  { href: "/products/dusk", label: "Shop" },
  { href: "/science", label: "Science" },
  { href: "/protocol", label: "Protocol" },
  { href: "/about", label: "About" },
  { href: "/faq", label: "FAQ" }
];

export function Navigation() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-black/10 bg-hrv-white/80 backdrop-blur">
      <div className="mx-auto flex max-w-[1400px] items-center justify-between px-6 py-4">
        <Link href="/" className="flex items-center gap-2">
          <span className="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-black text-white text-sm font-semibold">
            H
          </span>
          <span className="text-sm font-semibold tracking-wide">HRV</span>
        </Link>

        <nav className="hidden items-center gap-7 md:flex">
          {links.map((l) => (
            <Link key={l.href} href={l.href} className="text-sm text-black/75 hover:text-black">
              {l.label}
            </Link>
          ))}
          <Button href="/products/dusk" className="ml-2">
            Shop HRV Dusk
          </Button>
        </nav>

        <button
          className="md:hidden rounded-xl border border-black/10 px-3 py-2 text-sm"
          onClick={() => setOpen((v) => !v)}
          aria-label="Open menu"
        >
          {open ? "Close" : "Menu"}
        </button>
      </div>

      {open && (
        <div className="md:hidden border-t border-black/10 bg-hrv-white">
          <div className="mx-auto max-w-[1400px] px-6 py-4 flex flex-col gap-3">
            {links.map((l) => (
              <Link
                key={l.href}
                href={l.href}
                className="rounded-xl px-3 py-2 text-sm text-black/80 hover:bg-black/[0.04]"
                onClick={() => setOpen(false)}
              >
                {l.label}
              </Link>
            ))}
            <Button href="/products/dusk" fullWidth>
              Shop HRV Dusk
            </Button>
          </div>
        </div>
      )}
    </header>
  );
}
