"use client";
import { motion } from "framer-motion";

export const FadeUp = motion.div;
