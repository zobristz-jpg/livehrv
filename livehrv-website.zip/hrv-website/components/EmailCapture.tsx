"use client";

import { useState } from "react";
import { Button } from "@/components/Button";

export function EmailCapture() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email.trim()) return;
    // Placeholder: connect to Klaviyo/ConvertKit later.
    setSubmitted(true);
  }

  return (
    <div className="rounded-2xl border border-black/10 bg-white p-6 shadow-soft">
      <div className="flex flex-col gap-2">
        <p className="text-xs font-medium tracking-wide text-black/60">JOIN THE RITUAL</p>
        <h3 className="font-display text-2xl md:text-3xl">Get 10% off your first order</h3>
        <p className="text-sm text-black/70">
          Plus a simple Night Recovery Ritual guide. No hype. Just discipline.
        </p>
      </div>

      {submitted ? (
        <div className="mt-5 rounded-xl bg-black/[0.04] p-4 text-sm text-black/75">
          You’re in. Watch your inbox.
        </div>
      ) : (
        <form onSubmit={onSubmit} className="mt-5 flex flex-col gap-3 sm:flex-row">
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email address"
            className="w-full rounded-xl border border-black/15 bg-white px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-black/15"
            type="email"
            required
          />
          <Button type="submit" className="sm:w-[160px]">
            Join
          </Button>
        </form>
      )}
      <p className="mt-3 text-xs text-black/45">
        By joining, you agree to receive emails from HRV. Unsubscribe anytime.
      </p>
    </div>
  );
}
