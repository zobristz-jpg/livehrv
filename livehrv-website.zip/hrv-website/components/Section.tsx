export function Section({
  eyebrow,
  title,
  subtitle,
  children
}: {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  children?: React.ReactNode;
}) {
  return (
    <section className="py-16 md:py-20">
      <div className="mx-auto max-w-[1400px] px-6">
        {eyebrow ? (
          <p className="text-xs font-medium tracking-wide text-black/60">{eyebrow}</p>
        ) : null}
        <div className="mt-2 max-w-3xl">
          <h2 className="font-display text-3xl md:text-4xl">{title}</h2>
          {subtitle ? <p className="mt-3 text-sm md:text-base text-black/70">{subtitle}</p> : null}
        </div>
        {children ? <div className="mt-10">{children}</div> : null}
      </div>
    </section>
  );
}
