# HRV Website (livehrv.com)

A production-ready Next.js marketing website for HRV.

## Quick Start (Local)

1. Install Node.js 18+
2. In this folder:

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Deploy (Vercel)

- Push this repo to GitHub
- Import into Vercel
- Deploy

## Edit content

All product copy, formula, FAQs, and testimonials live in:

`data/content.ts`
