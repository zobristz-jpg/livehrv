export const brand = {
  name: "HRV",
  domain: "livehrv.com",
  tagline: "Night Recovery Ritual",
  pillars: [
    {
      title: "Sleep is Worship",
      description:
        "We treat rest like a discipline—reverent, intentional, and protected."
    },
    {
      title: "Recovery is Stewardship",
      description:
        "Recovery isn't optional. It's how you stay ready to serve, lead, and endure."
    },
    {
      title: "Strength is Service",
      description:
        "We pursue strength so we can carry more—for our families, our teams, and our callings."
    }
  ]
};

export const product = {
  slug: "dusk",
  name: "HRV Dusk",
  subtitle: "Night Recovery Ritual",
  servings: 30,
  servingSizeG: 8.5,
  netWeightG: 255,
  flavorOptions: ["Wild Honey", "Honey Vanilla"],
  price: 54,
  subscribeDiscountPercent: 10,
  shippingNote: "Free shipping over $75. Ships in 1–2 business days.",
  guarantee: "30-day money-back guarantee.",
  highlights: [
    "Research-backed doses. No proprietary blends.",
    "Designed for disciplined athletes and purpose-driven leaders.",
    "Mixes hot or cold with water or milk.",
    "Calm, clean taste—never candy."
  ],
  formula: [
    { ingredient: "L-Theanine", dose: "300 mg", purpose: "Supports calm and sleep onset" },
    { ingredient: "Inositol", dose: "2,000 mg", purpose: "Supports nervous system balance" },
    { ingredient: "Magnesium (as magnesium oxide)", dose: "200 mg", purpose: "Supports relaxation and recovery" },
    { ingredient: "Glycine", dose: "3,000 mg", purpose: "Supports deeper rest and next-day readiness" },
    { ingredient: "Apigenin", dose: "50 mg", purpose: "Supports a calmer evening wind-down" },
    { ingredient: "PeptiSleep (Nuritas sleep peptide)", dose: "250 mg", purpose: "Supports sleep quality and recovery" }
  ],
  howToUse: {
    timing: "30–60 minutes before bed",
    mix: "1 scoop with 8–12 oz water or milk",
    hotOrCold: "Enjoy hot or cold",
    consistency: "Use nightly for best results"
  },
  taste: "Lightly sweet, warm finish, clean and restrained—built for a nightly ritual."
};

export const testimonials = [
  {
    name: "Mason T.",
    role: "HYROX athlete",
    quote:
      "Dusk feels like a switch—calm comes on, sleep is deeper, and I wake up ready to train."
  },
  {
    name: "Jordan K.",
    role: "CrossFit coach & dad",
    quote:
      "It’s the first sleep supplement I can take every night without feeling foggy the next morning."
  },
  {
    name: "Avery S.",
    role: "Endurance / strength hybrid",
    quote:
      "Simple, clean, and premium. No hype. Just a ritual that supports recovery."
  }
];

export const faq = {
  product: [
    {
      q: "What is HRV Dusk?",
      a:
        "HRV Dusk is a powdered nighttime recovery supplement designed to support calm, sleep quality, and next-day readiness—built for disciplined athletes and purpose-driven leaders."
    },
    {
      q: "Will it make me groggy?",
      a:
        "Most people report feeling calmer at night and clear in the morning. Start with a half serving if you’re sensitive."
    },
    {
      q: "When should I take it?",
      a:
        "30–60 minutes before bed. Make it part of a consistent night routine."
    },
    {
      q: "Can I mix it with water or milk? Hot or cold?",
      a:
        "Yes—HRV Dusk is designed to mix hot or cold with water or milk."
    },
    {
      q: "How does it taste?",
      a:
        "Honey-forward, lightly sweet, and restrained. It’s a ritual flavor—not candy."
    },
    {
      q: "Is this third-party tested?",
      a:
        "This site includes placeholders for quality standards. Add your actual COAs and testing details before launch."
    }
  ],
  science: [
    {
      q: "What is HRV and why does it matter?",
      a:
        "HRV (heart rate variability) is one signal your body uses to reflect recovery and readiness. Better sleep and recovery habits often correlate with improved next-day resilience."
    },
    {
      q: "Why these ingredients?",
      a:
        "Each ingredient is selected for a specific role in calm, sleep quality, and recovery—at transparent doses without proprietary blends."
    },
    {
      q: "Are the doses effective?",
      a:
        "The formula uses meaningful, label-forward doses. Individual response varies; consistency matters."
    },
    {
      q: "Is this medical advice?",
      a:
        "No. This is general information. Consult a qualified healthcare professional for personalized guidance."
    }
  ],
  ordering: [
    {
      q: "How does Subscribe & Save work?",
      a:
        "Choose a recurring delivery cadence and receive a discount. You can pause or cancel anytime (when implemented through your e-commerce platform)."
    },
    {
      q: "What’s the return policy?",
      a:
        "Use the 30-day money-back guarantee as your baseline policy and adjust to your operational reality."
    },
    {
      q: "Do you ship internationally?",
      a:
        "International shipping availability depends on your fulfillment setup. Update this section before launch."
    },
    {
      q: "How can I contact support?",
      a:
        "Email support@livehrv.com. Replace with your real support inbox when ready."
    }
  ]
};
